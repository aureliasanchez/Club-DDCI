<!DOCTYPE html>
<!--[if IE 8]> <html lang="en-US" class="ie8"> <![endif]-->
<!--[if !IE]><!--> <html lang="en-US"> <!--<![endif]-->
<head>
<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="shortcut icon" href="https://htmlbeans.com/wp-content/uploads/2019/02/faviicon.jpg" /><meta name="msapplication-TileColor" content="#ffffff">
<meta name="theme-color" content="#ffffff">

<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="https://htmlbeans.com/xmlrpc.php">

<title>Page not found &#8211; HtmlBeans</title>
<meta name='robots' content='max-image-preview:large' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="HtmlBeans &raquo; Feed" href="https://htmlbeans.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="HtmlBeans &raquo; Comments Feed" href="https://htmlbeans.com/comments/feed/" />
<script type="text/javascript">
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/htmlbeans.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.2.6"}};
/*! This file is auto-generated */
!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){p.clearRect(0,0,i.width,i.height),p.fillText(e,0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(t,0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(p&&p.fillText)switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s("\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!s("\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!s("\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!s("\ud83e\udef1\ud83c\udffb\u200d\ud83e\udef2\ud83c\udfff","\ud83e\udef1\ud83c\udffb\u200b\ud83e\udef2\ud83c\udfff")}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(e=t.source||{}).concatemoji?c(e.concatemoji):e.wpemoji&&e.twemoji&&(c(e.twemoji),c(e.wpemoji)))}(window,document,window._wpemojiSettings);
</script>
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 0.07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css' href='https://htmlbeans.com/wp-includes/css/dist/block-library/style.min.css?ver=6.2.6' type='text/css' media='all' />
<link rel='stylesheet' id='classic-theme-styles-css' href='https://htmlbeans.com/wp-includes/css/classic-themes.min.css?ver=6.2.6' type='text/css' media='all' />
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');--wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');--wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');--wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');--wp--preset--duotone--midnight: url('#wp-duotone-midnight');--wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');--wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');--wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='contact-form-7-css' href='https://htmlbeans.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='wp-pagenavi-css' href='https://htmlbeans.com/wp-content/plugins/wp-pagenavi/pagenavi-css.css?ver=2.70' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css' href='https://htmlbeans.com/wp-content/plugins/js_composer/assets/lib/bower/font-awesome/css/font-awesome.min.css?ver=5.6' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css-css' href='https://htmlbeans.com/wp-content/themes/elston/assets/css/bootstrap.min.css?ver=3.3.6' type='text/css' media='all' />
<link rel='stylesheet' id='simple-line-icons-css' href='https://htmlbeans.com/wp-content/themes/elston/assets/css/simple-line-icons.css?ver=2.3.2' type='text/css' media='all' />
<link rel='stylesheet' id='elston-owl-carousel-css' href='https://htmlbeans.com/wp-content/themes/elston/assets/css/owl.carousel.css?ver=2.4' type='text/css' media='all' />
<link rel='stylesheet' id='elston-fullpage-css' href='https://htmlbeans.com/wp-content/themes/elston/assets/css/fullpage.css?ver=2.8.2' type='text/css' media='all' />
<link rel='stylesheet' id='elston-magnific-popup-css' href='https://htmlbeans.com/wp-content/themes/elston/assets/css/magnific-popup.css?ver=1.6' type='text/css' media='all' />
<link rel='stylesheet' id='elston-style-css' href='https://htmlbeans.com/wp-content/themes/elston/assets/css/styles.css?ver=1.6' type='text/css' media='all' />
<link rel='stylesheet' id='elston-responsive-css' href='https://htmlbeans.com/wp-content/themes/elston/assets/css/responsive.css?ver=1.6' type='text/css' media='all' />
<link rel='stylesheet' id='elston-google-fonts-css' href='//fonts.googleapis.com/css?family=Poppins%3A300%2C400%2C500%2C600%2C700%7CRaleway%3A300%2C400%2C500%2C600%2C700%7CMerriweather%3A300%2C400%2C500%2C600%2C700%7CLora%3A300%2C400%2C500%2C600%2C700&#038;subset=latin' type='text/css' media='all' />
<link rel='stylesheet' id='elston-default-style-css' href='https://htmlbeans.com/wp-content/themes/elston/style.css?ver=6.2.6' type='text/css' media='all' />
<style id='elston-default-style-inline-css' type='text/css'>
.no-class {}.vt-maintenance-mode {}body, .details-wrapper p, .deatil-item p, .elstn-portfolio-detail .elstn-testimonials .testimonial-owner, .elstn-portfolio-detail.spacer2 .elstn-detail-wrap p, .elstn-portfolio-detail.version2 .elstn-detail-container p, .elstn-detail-wrap p, .elstn-detail-wrap p a, .target-info p, .elstn-detail-container.version2 p, .elstn-top-title p, .contact-list p, .elstn-btn, input[type="submit"], input[type="text"], input[type="email"], input[type="tel"], input[type="search"], input[type="date"], input[type="time"], input[type="datetime-local"], input[type="month"], input[type="url"], input[type="number"], textarea, select, .form-control, p, .service-info p{font-family:"Poppins", Arial, sans-serif;font-size:14px;line-height:1.42857143;font-style:normal;}nav{font-family:"Poppins", Arial, sans-serif;font-size:12px;line-height:24px;font-style:normal;}nav ul li.sub-menu-item ul.sub-menu{font-family:"Poppins", Arial, sans-serif;font-size:13px;font-style:normal;}h1, h2, h3, h4, h5, h6,.elstn-services.version2 .service-info h4,.elstn-blog-detail h4.poppins-font,.elstn-blog-detail h4,.elstn-detail-container .elstn-heading-wrap .elstn-sub-heading, .portfolio-title, .deatil-item h4, .elstn-portfolio-detail .elstn-testimonials p{font-family:"Poppins", Arial, sans-serif;font-style:normal;}.content-inner, .elstn-top-banner .banner-caption h4, .elstn-blog-detail p, .content-inner h5, .content-inner h6,.content-inner ul li, .content-inner ol li{font-family:"Raleway", Arial, sans-serif;font-style:normal;}.blog-date, .elstn-testimonials p, .service-info h4,.elstn-about-wrap p,.mate-name .clearfix,.service-info h4,.testimonial-owner span,.elstn-top-title h1,.elstn-detail-wrap .elstn-heading-wrap span,.elstn-detail-container.version2 ul li,.portfolio-caption a,.elstn-masonry .item .item-info h6,.banner-caption a,.elstn-top-banner .banner-caption h1{font-family:"Merriweather", Arial, sans-serif;font-style:normal;}.content-inner blockquote, blockquote, .elstn-heading-wrap span, .about-text h4{font-family:"Lora", Arial, sans-serif;font-style:normal;}.your-custom-class{font-family:"Raleway", Arial, sans-serif;font-style:normal;}
</style>
<script type='text/javascript' src='https://htmlbeans.com/wp-includes/js/jquery/jquery.min.js?ver=3.6.4' id='jquery-core-js'></script>
<script type='text/javascript' src='https://htmlbeans.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.0' id='jquery-migrate-js'></script>
<link rel="https://api.w.org/" href="https://htmlbeans.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://htmlbeans.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://htmlbeans.com/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 6.2.6" />
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="https://htmlbeans.com/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>

  <body class="error404 wpb-js-composer js-comp-ver-5.6 vc_responsive">


<div id="elston-wrapper" class="clickevent"> <!-- #elston-wrapper -->

  <!-- elstn sidebar -->
    <div class="elstn-sidebar">
    <div class="sidebar-part1">
      <div class="menu-wrapper">
        <div class="logo elston-logo" style="">
	<a href="https://htmlbeans.com/">
	<img src="https://htmlbeans.com/wp-content/uploads/2019/02/logo.png" alt="HtmlBeans" class="default-logo" /></a></div>        <nav>
          <ul id="main-nav" class="nav-slyder"><li id="menu-item-745" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-745"><a href="https://htmlbeans.com/portfolio/">Portfolio</a></li>
<li id="menu-item-155" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-155"><a href="https://htmlbeans.com/about-studio/">About Studio</a></li>
<li id="menu-item-157" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-157"><a href="https://htmlbeans.com/services/">Services</a></li>
<li id="menu-item-566" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-566"><a href="https://htmlbeans.com/journal/">Journal</a></li>
<li id="menu-item-156" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-156"><a href="https://htmlbeans.com/contact/">Contact</a></li>
</ul>                    <ul id="portfolio-nav" class="filter-buttons">
            <li><a href="https://htmlbeans.com/" data-filter="*">All</a></li><li><a href="https://htmlbeans.com/portfolio-category_cat/css/" data-filter=".cat-css">Css</a></li><li><a href="https://htmlbeans.com/portfolio-category_cat/html/" data-filter=".cat-html">Html</a></li><li><a href="https://htmlbeans.com/portfolio-category_cat/javascript/" data-filter=".cat-javascript">Javascript</a></li><li><a href="https://htmlbeans.com/portfolio-category_cat/php/" data-filter=".cat-php">Php</a></li><li><a href="https://htmlbeans.com/portfolio-category_cat/psd/" data-filter=".cat-psd">PSD</a></li><li><a href="https://htmlbeans.com/portfolio-category_cat/wordpress/" data-filter=".cat-wordpress">WordPress</a></li>          </ul>
                  </nav>
      </div>
            <div class="contact-links">
                <div class="elstn-social-links">
                  </div>
              </div>
          </div>
    <div class="sidebar-part2">
            <div class="logo2">
        <a href="https://htmlbeans.com/"><img src="https://htmlbeans.com/wp-content/themes/elston/assets/images/logo/logo2.png" alt=""/></a>
      </div>
      
      <div class="elstn-table-container">
        <div class="elstn-align-container">
          <div class="action-links">
            <a href="javascript:void(0);" class="toggle-link"><span></span></a>
                          <a href="javascript:void(0);" class="grid-link"><span></span> <span></span> <span></span></a>
                                      <a href="javascript:void(0);" class="search-link"><i class="icons icon-magnifier"></i></a>
                      </div>
        </div>
      </div>

    </div>
  </div>

  <!-- elstn toggle button -->
  <div class="elstn-toggle-btn"><a href="javascript:void(0);"><span></span> <span></span> <span></span></a></div>

  <!-- elstn search wrapper -->
  <div class="elstn-search-wrap">
    <div class="elstn-table-container">
      <div class="elstn-align-container">
        <div class="search-closer"></div>
        <div class="search-container">
          <form method="get" id="searchform" action="https://htmlbeans.com/">
            <input type="text" name="s" id="s" placeholder="Start Searching" class="search-input"/>
          </form>
          <span>SEARCH AND PRESS ENTER</span>
        </div>
      </div>
    </div>
  </div>

  <!-- elstn wrapper -->
  <div class="elstn-wrapper">
    <div class="elstn-wrap-inner">
	<!-- Content -->
	<div class="blog-single-page">
		<div class="blog-single-page-inner">
			<div class="container">

				<div class="elstn-top-title error-content">
					<img src="https://htmlbeans.com/wp-content/themes/elston/assets/images/404.png" alt="404 Error">
					<h1>Sorry! The Page Not Found</h1>
					<p>The Link You Followed Probably Broken, Or The Page Has Been Removed From Website.</p>
					<div class="contact-button"><a href="https://htmlbeans.com/" class="elstn-btn elstn-btn-one elstn-btn-large">BACK TO HOME</a></div>
				</div>

			</div>
		</div>
	</div>
	<!-- Content -->

	<!-- Footer -->
	<footer class="elstn-footer">
		© 2019 Htmlbeans. All right reserved.<br/>	</footer>
	<!-- Footer -->
	  </div>
	</div>

	<!-- elstn back top -->
	<div class="elstn-back-top">
	  <a href="#0"><i class="fa fa-angle-up" aria-hidden="true"></i></a>
	</div>
</div><!-- #elston-wrapper -->
<script type='text/javascript' id='elston-load-posts-js-extra'>
/* <![CDATA[ */
var pbd_alp = {"startPage":"1","maxPages":"1","nextLink":"","class_name":"item","more_text":"Load More","loading_text":"Loading ....","end_text":"No More Post","is_search":"","home_url":"https:\/\/htmlbeans.com\/"};
/* ]]> */
</script>
<script type='text/javascript' src='https://htmlbeans.com/wp-content/themes/elston/assets/js/load-more.js?ver=1.0' id='elston-load-posts-js'></script>
<script type='text/javascript' id='elston-load-portfolio-posts-js-extra'>
/* <![CDATA[ */
var pbd_alp_portfolio = {"startPage":"1","maxPages":"4","nextLink":"https:\/\/htmlbeans.com\/html\/swan\/Popover%20requires%20tooltip.js\/page\/2\/","more_text":"Load More","loading_text":"Loading ....","end_text":"No More Post"};
/* ]]> */
</script>
<script type='text/javascript' src='https://htmlbeans.com/wp-content/themes/elston/assets/js/portfolio-load-more.js?ver=1.0' id='elston-load-portfolio-posts-js'></script>
<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/htmlbeans.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://htmlbeans.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.1.1' id='contact-form-7-js'></script>
<script type='text/javascript' src='https://htmlbeans.com/wp-content/themes/elston/assets/js/bootstrap.min.js?ver=3.3.6' id='bootstrap-js-js'></script>
<script type='text/javascript' src='https://htmlbeans.com/wp-content/themes/elston/assets/js/hoverdir.js?ver=1.1.2' id='elston-hoverdir-js'></script>
<script type='text/javascript' src='https://htmlbeans.com/wp-content/themes/elston/assets/js/plugins.js?ver=1.6' id='elston-plugins-js'></script>
<script type='text/javascript' src='https://htmlbeans.com/wp-content/themes/elston/assets/js/scripts.js?ver=1.6' id='elston-scripts-js'></script>
<script type='text/javascript' src='https://htmlbeans.com/wp-content/themes/elston/assets/js/jquery.validate.min.js?ver=1.9.0' id='elston-validate-js-js'></script>
<script type='text/javascript' id='elston-validate-js-js-after'>
jQuery(document).ready(function($) {$("#commentform").validate({rules: {author: {required: true,minlength: 2},email: {required: true,email: true},comment: {required: true,minlength: 10}}});});
</script>
</body>
</html>